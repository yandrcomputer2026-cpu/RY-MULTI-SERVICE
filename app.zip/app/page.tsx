export default function LoginPage() {
  return (
    <main className="min-h-screen bg-gray-100 flex items-center justify-center px-4">

      <div className="w-full max-w-md">

        {/* Logo / Brand */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-blue-700">
            RY MULTI SERVICE
          </h1>

          <p className="text-gray-600 mt-2">
            Login to your account
          </p>
        </div>


        {/* Login Card */}
        <div className="bg-white rounded-2xl shadow-lg p-8">

          <h2 className="text-2xl font-bold text-gray-900">
            Welcome Back
          </h2>

          <p className="text-gray-500 mt-2">
            Please enter your details to continue.
          </p>


          {/* Mobile / Email */}
          <div className="mt-6">

            <label
              htmlFor="email"
              className="block text-sm font-medium text-gray-700 mb-2"
            >
              Mobile Number / Email
            </label>

            <input
              id="email"
              type="text"
              placeholder="Enter mobile number or email"
              className="w-full border border-gray-300 rounded-lg px-4 py-3 outline-none focus:ring-2 focus:ring-blue-500"
            />

          </div>


          {/* Password */}
          <div className="mt-5">

            <div className="flex justify-between mb-2">

              <label
                htmlFor="password"
                className="text-sm font-medium text-gray-700"
              >
                Password
              </label>

              <a
                href="#"
                className="text-sm text-blue-600 hover:underline"
              >
                Forgot Password?
              </a>

            </div>

            <input
              id="password"
              type="password"
              placeholder="Enter password"
              className="w-full border border-gray-300 rounded-lg px-4 py-3 outline-none focus:ring-2 focus:ring-blue-500"
            />

          </div>


          {/* Login Button */}
          <button
            type="button"
            className="w-full mt-7 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 rounded-lg"
          >
            Login
          </button>


          {/* Register */}
          <p className="text-center text-gray-600 mt-6">

            Don't have an account?{" "}

            <a
              href="/register"
              className="text-blue-600 font-semibold hover:underline"
            >
              Create Account
            </a>

          </p>

        </div>


        {/* Back to Home */}
        <div className="text-center mt-6">

          <a
            href="/"
            className="text-gray-600 hover:text-blue-600"
          >
            ← Back to Home
          </a>

        </div>

      </div>

    </main>
  );
}