"use client";

import Link from "next/link";
import { useEffect, useState } from "react";

type Transaction = {
  id: number;
  transactionId: string;
  service: string;
  category: string | null;
  description: string | null;
  amount: string;
  status: string;
  referenceId: string | null;
  provider: string | null;
  createdAt: string;
  razorpayOrderId: string | null;
  razorpayPaymentId: string | null;
};

export default function PaymentHistoryPage() {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    async function loadHistory() {
      try {
        setLoading(true);
        setError("");

        const response = await fetch("/api/payment/history", {
          method: "GET",
          cache: "no-store",
        });

        const data = await response.json();

        if (!response.ok || !data.success) {
          setError(
            data.message || "Payment history load नहीं हो सकी।"
          );
          return;
        }

        setTransactions(data.transactions || []);
      } catch (error) {
        console.error("HISTORY LOAD ERROR:", error);

        setError("Server से connection नहीं हो पाया।");
      } finally {
        setLoading(false);
      }
    }

    loadHistory();
  }, []);

  function getStatusClass(status: string) {
    switch (status.toUpperCase()) {
      case "SUCCESS":
      case "RECHARGE_SUCCESS":
        return "bg-green-100 text-green-700";

      case "FAILED":
      case "RECHARGE_FAILED":
        return "bg-red-100 text-red-700";

      case "PENDING":
        return "bg-yellow-100 text-yellow-700";

      default:
        return "bg-gray-100 text-gray-700";
    }
  }

  function getServiceName(service: string) {
    switch (service) {
      case "MOBILE_PREPAID":
        return "Mobile Prepaid Recharge";

      case "MOBILE_POSTPAID":
        return "Mobile Postpaid";

      case "DTH":
        return "DTH Recharge";

      case "ELECTRICITY":
        return "Electricity Bill";

      case "INTERNET_TV":
        return "Internet / TV Bill";

      default:
        return service;
    }
  }

  return (
    <main className="min-h-screen bg-gray-100">

      {/* HEADER */}

      <header className="bg-white shadow-sm px-6 py-4">
        <div className="max-w-6xl mx-auto flex items-center justify-between">

          <h1 className="text-xl font-bold text-blue-700">
            RY MULTI SERVICE
          </h1>

          <div className="flex items-center gap-6">

            <Link
              href="/dashboard"
              className="text-gray-600 hover:text-blue-600"
            >
              Dashboard
            </Link>

            <Link
              href="/service1"
              className="text-gray-600 hover:text-blue-600"
            >
              Online Payments
            </Link>

          </div>
        </div>
      </header>

      {/* MAIN */}

      <div className="max-w-6xl mx-auto px-6 py-10">

        {/* PAGE HEADING */}

        <div className="mb-8">

          <h2 className="text-3xl font-bold text-gray-900">
            📊 Payment History
          </h2>

          <p className="text-gray-600 mt-2">
            आपके सभी payment और recharge की जानकारी।
          </p>

        </div>

        {/* LOADING */}

        {loading && (
          <div className="bg-white rounded-xl shadow p-8 text-center">

            <p className="text-gray-600">
              Payment history loading...
            </p>

          </div>
        )}

        {/* ERROR */}

        {!loading && error && (
          <div className="bg-red-50 border border-red-200 text-red-700 rounded-xl p-5">

            {error}

          </div>
        )}

        {/* EMPTY */}

        {!loading &&
          !error &&
          transactions.length === 0 && (

            <div className="bg-white rounded-xl shadow p-10 text-center">

              <div className="text-5xl">
                📭
              </div>

              <h3 className="text-xl font-bold text-gray-900 mt-4">
                No Transactions Yet
              </h3>

              <p className="text-gray-500 mt-2">
                अभी तक कोई payment या recharge नहीं किया गया है।
              </p>

              <Link
                href="/service1/mobile-prepaid"
                className="inline-block mt-6 bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700"
              >
                Mobile Recharge करें →
              </Link>

            </div>
          )}

        {/* TRANSACTIONS */}

        {!loading &&
          !error &&
          transactions.length > 0 && (

            <div className="space-y-5">

              {transactions.map((transaction) => (

                <div
                  key={transaction.id}
                  className="bg-white rounded-xl shadow p-6 hover:shadow-lg transition"
                >

                  <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-5">

                    {/* LEFT */}

                    <div className="flex-1">

                      <h3 className="text-xl font-bold text-gray-900">
                        {getServiceName(transaction.service)}
                      </h3>

                      {transaction.description && (
                        <p className="text-sm text-gray-500 mt-2">
                          {transaction.description}
                        </p>
                      )}

                      <div className="mt-4 space-y-2 text-sm">

                        <p>
                          <span className="font-semibold">
                            Transaction ID:
                          </span>{" "}
                          {transaction.transactionId}
                        </p>

                        {transaction.provider && (
                          <p>
                            <span className="font-semibold">
                              Operator:
                            </span>{" "}
                            {transaction.provider.toUpperCase()}
                          </p>
                        )}

                        {transaction.referenceId && (
                          <p>
                            <span className="font-semibold">
                              Reference:
                            </span>{" "}
                            {transaction.referenceId}
                          </p>
                        )}

                        <p>
                          <span className="font-semibold">
                            Date:
                          </span>{" "}
                          {new Date(
                            transaction.createdAt
                          ).toLocaleString("en-IN")}
                        </p>

                      </div>

                      {/* VIEW DETAILS */}

                      <div className="mt-5">

                        <Link
                          href={`/service1/history/${encodeURIComponent(
                            transaction.transactionId
                          )}`}
                          className="inline-flex items-center bg-blue-600 text-white px-5 py-2.5 rounded-lg font-semibold hover:bg-blue-700 transition"
                        >
                          View Details →
                        </Link>

                      </div>

                    </div>

                    {/* RIGHT */}

                    <div className="md:text-right">

                      <p className="text-2xl font-bold text-gray-900">
                        ₹{transaction.amount}
                      </p>

                      <span
                        className={`inline-block mt-3 px-4 py-1 rounded-full text-sm font-semibold ${getStatusClass(
                          transaction.status
                        )}`}
                      >
                        {transaction.status}
                      </span>

                    </div>

                  </div>

                </div>

              ))}

            </div>
          )}

        {/* BACK */}

        <div className="mt-10">

          <Link
            href="/service1"
            className="inline-block bg-gray-800 text-white px-6 py-3 rounded-lg hover:bg-gray-900"
          >
            ← Online Payments पर वापस जाएँ
          </Link>

        </div>

      </div>

    </main>
  );
}