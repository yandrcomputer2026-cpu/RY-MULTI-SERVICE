"use client";

import Link from "next/link";
import { useParams } from "next/navigation";
import { useEffect, useState } from "react";

type Transaction = {
  id: number;
  transactionId: string;
  service: string;
  category: string | null;
  description: string | null;
  amount: string;
  status: string;
  referenceId: string | null;
  provider: string | null;
  createdAt: string;
  updatedAt: string;
  razorpayOrderId: string | null;
  razorpayPaymentId: string | null;
};

export default function TransactionDetailsPage() {
  const params = useParams();

  const transactionId = params.transactionId as string;

  const [transaction, setTransaction] =
    useState<Transaction | null>(null);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  // ================= LOAD TRANSACTION =================

  useEffect(() => {
    async function loadTransaction() {
      try {
        setLoading(true);
        setError("");

        if (!transactionId) {
          setError("Invalid transaction ID.");
          return;
        }

        const response = await fetch(
          `/api/payment/transaction/${encodeURIComponent(
            transactionId
          )}`,
          {
            method: "GET",
            cache: "no-store",
          }
        );

        const data = await response.json();

        if (!response.ok || !data.success) {
          setError(
            data.message ||
              "Transaction details load नहीं हो सकी।"
          );
          return;
        }

        setTransaction(data.transaction);
      } catch (error) {
        console.error(
          "TRANSACTION DETAILS ERROR:",
          error
        );

        setError(
          "Server से connection नहीं हो पाया।"
        );
      } finally {
        setLoading(false);
      }
    }

    loadTransaction();
  }, [transactionId]);

  // ================= STATUS STYLE =================

  function getStatusClass(status: string) {
    switch (status.toUpperCase()) {
      case "SUCCESS":
      case "RECHARGE_SUCCESS":
        return "bg-green-100 text-green-700";

      case "FAILED":
      case "RECHARGE_FAILED":
        return "bg-red-100 text-red-700";

      case "PENDING":
        return "bg-yellow-100 text-yellow-700";

      default:
        return "bg-gray-100 text-gray-700";
    }
  }

  // ================= SERVICE NAME =================

  function getServiceName(service: string) {
    switch (service) {
      case "MOBILE_PREPAID":
        return "Mobile Prepaid Recharge";

      case "MOBILE_POSTPAID":
        return "Mobile Postpaid";

      case "DTH":
        return "DTH Recharge";

      case "ELECTRICITY":
        return "Electricity Bill";

      case "INTERNET_TV":
        return "Internet / TV Bill";

      default:
        return service;
    }
  }

  // ================= LOADING =================

  if (loading) {
    return (
      <main className="min-h-screen bg-gray-100">

        <header className="bg-white shadow-sm px-6 py-4">
          <div className="max-w-6xl mx-auto">

            <h1 className="text-xl font-bold text-blue-700">
              RY MULTI SERVICE
            </h1>

          </div>
        </header>

        <div className="max-w-4xl mx-auto px-6 py-16">

          <div className="bg-white rounded-xl shadow p-10 text-center">

            <div className="text-4xl">
              ⏳
            </div>

            <p className="text-gray-600 mt-4">
              Transaction details loading...
            </p>

          </div>

        </div>

      </main>
    );
  }

  // ================= ERROR =================

  if (error || !transaction) {
    return (
      <main className="min-h-screen bg-gray-100">

        <header className="bg-white shadow-sm px-6 py-4">
          <div className="max-w-6xl mx-auto">

            <h1 className="text-xl font-bold text-blue-700">
              RY MULTI SERVICE
            </h1>

          </div>
        </header>

        <div className="max-w-4xl mx-auto px-6 py-16">

          <div className="bg-red-50 border border-red-200
            text-red-700 rounded-xl p-8 text-center">

            <div className="text-4xl">
              ❌
            </div>

            <h2 className="text-xl font-bold mt-4">
              Transaction Not Found
            </h2>

            <p className="mt-2">
              {error ||
                "Transaction details उपलब्ध नहीं हैं।"}
            </p>

            <Link
              href="/service1/history"
              className="inline-block mt-6
                bg-gray-800 text-white
                px-6 py-3 rounded-lg
                hover:bg-gray-900"
            >
              ← Payment History पर वापस जाएँ
            </Link>

          </div>

        </div>

      </main>
    );
  }

  // ================= MAIN =================

  return (
    <main className="min-h-screen bg-gray-100">

      {/* ================= HEADER ================= */}

      <header className="bg-white shadow-sm px-6 py-4">

        <div className="max-w-6xl mx-auto
          flex items-center justify-between">

          <h1 className="text-xl font-bold text-blue-700">
            RY MULTI SERVICE
          </h1>

          <div className="flex items-center gap-6">

            <Link
              href="/dashboard"
              className="text-gray-600 hover:text-blue-600"
            >
              Dashboard
            </Link>

            <Link
              href="/service1/history"
              className="text-gray-600 hover:text-blue-600"
            >
              Payment History
            </Link>

          </div>

        </div>

      </header>


      {/* ================= MAIN CONTENT ================= */}

      <div className="max-w-4xl mx-auto px-6 py-10">

        {/* ================= HEADING ================= */}

        <div className="mb-8">

          <h2 className="text-3xl font-bold text-gray-900">
            🧾 Transaction Details
          </h2>

          <p className="text-gray-600 mt-2">
            आपके payment की पूरी जानकारी।
          </p>

        </div>


        {/* ================= STATUS ================= */}

        <div className="bg-white rounded-xl shadow p-6">

          <div className="flex flex-col md:flex-row
            md:items-center md:justify-between gap-4">

            <div>

              <p className="text-sm text-gray-500">
                Payment Status
              </p>

              <span
                className={`inline-block mt-2
                  px-4 py-2 rounded-full
                  text-sm font-bold
                  ${getStatusClass(
                    transaction.status
                  )}`}
              >
                {transaction.status}
              </span>

            </div>

            <div className="md:text-right">

              <p className="text-sm text-gray-500">
                Amount
              </p>

              <p className="text-3xl font-bold text-gray-900">
                ₹{transaction.amount}
              </p>

            </div>

          </div>

        </div>


        {/* ================= TRANSACTION INFORMATION ================= */}

        <div className="bg-white rounded-xl shadow p-6 mt-6">

          <h3 className="text-xl font-bold text-gray-900">
            Transaction Information
          </h3>

          <div className="mt-6 space-y-4">

            <div>
              <p className="text-sm text-gray-500">
                Transaction ID
              </p>

              <p className="font-semibold text-gray-900 break-all">
                {transaction.transactionId}
              </p>
            </div>


            <div>
              <p className="text-sm text-gray-500">
                Service
              </p>

              <p className="font-semibold text-gray-900">
                {getServiceName(
                  transaction.service
                )}
              </p>
            </div>


            {transaction.category && (
              <div>
                <p className="text-sm text-gray-500">
                  Category
                </p>

                <p className="font-semibold text-gray-900">
                  {transaction.category}
                </p>
              </div>
            )}


            {transaction.description && (
              <div>
                <p className="text-sm text-gray-500">
                  Description
                </p>

                <p className="font-semibold text-gray-900">
                  {transaction.description}
                </p>
              </div>
            )}


            {transaction.referenceId && (
              <div>
                <p className="text-sm text-gray-500">
                  Reference
                </p>

                <p className="font-semibold text-gray-900">
                  {transaction.referenceId}
                </p>
              </div>
            )}


            {transaction.provider && (
              <div>
                <p className="text-sm text-gray-500">
                  Provider / Operator
                </p>

                <p className="font-semibold text-gray-900">
                  {transaction.provider.toUpperCase()}
                </p>
              </div>
            )}


            <div>
              <p className="text-sm text-gray-500">
                Date & Time
              </p>

              <p className="font-semibold text-gray-900">
                {new Date(
                  transaction.createdAt
                ).toLocaleString("en-IN")}
              </p>
            </div>

          </div>

        </div>


        {/* ================= RAZORPAY INFORMATION ================= */}

        {(transaction.razorpayOrderId ||
          transaction.razorpayPaymentId) && (

          <div className="bg-white rounded-xl shadow p-6 mt-6">

            <h3 className="text-xl font-bold text-gray-900">
              Payment Gateway Information
            </h3>

            <div className="mt-6 space-y-4">

              {transaction.razorpayOrderId && (
                <div>

                  <p className="text-sm text-gray-500">
                    Razorpay Order ID
                  </p>

                  <p className="font-semibold text-gray-900 break-all">
                    {transaction.razorpayOrderId}
                  </p>

                </div>
              )}


              {transaction.razorpayPaymentId && (
                <div>

                  <p className="text-sm text-gray-500">
                    Razorpay Payment ID
                  </p>

                  <p className="font-semibold text-gray-900 break-all">
                    {transaction.razorpayPaymentId}
                  </p>

                </div>
              )}

            </div>

          </div>
        )}


        {/* ================= SUCCESS MESSAGE ================= */}

        {(
          transaction.status === "SUCCESS" ||
          transaction.status === "RECHARGE_SUCCESS"
        ) && (

          <div className="bg-green-50 border
            border-green-200 rounded-xl
            p-6 mt-6">

            <div className="flex items-start gap-4">

              <div className="text-3xl">
                ✅
              </div>

              <div>

                <h3 className="font-bold text-green-900">
                  Payment Successful
                </h3>

                <p className="text-green-800 mt-1">
                  आपका payment और recharge सफलतापूर्वक
                  complete हो गया है।
                </p>

              </div>

            </div>

          </div>
        )}


        {/* ================= BACK BUTTON ================= */}

        <div className="mt-8 flex flex-wrap gap-4">

          <Link
            href="/service1/history"
            className="bg-gray-800 text-white
              px-6 py-3 rounded-lg
              hover:bg-gray-900"
          >
            ← Payment History
          </Link>

          <Link
            href="/service1/mobile-prepaid"
            className="bg-blue-600 text-white
              px-6 py-3 rounded-lg
              hover:bg-blue-700"
          >
            New Recharge →
          </Link>

        </div>

      </div>

    </main>
  );
}